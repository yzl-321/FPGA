#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xil_types.h"
#include "xil_cache.h"
#include "xparameters.h"
#include "xgpio.h"
#include "xaxivdma.h"
#include "xaxivdma_i.h"
#include "display_ctrl/display_ctrl.h"
#include "vdma_api/vdma_api.h"
#include "emio_sccb_cfg/emio_sccb_cfg.h"
#include "ov5640/ov5640_init.h"
#include "xov5640_sobel.h"

#define BYTES_PIXEL        3                           //Number of pixel bytes, RGB888 3 bytes  RGB888
#define FRAME_BUFFER_NUM   3                           //frame buffer  3
#define DYNCLK_BASEADDR    XPAR_AXI_DYNCLK_0_BASEADDR  //(run)Dynamic clock  Base address
#define VDMA_ID            XPAR_AXIVDMA_0_DEVICE_ID    //VDMA  ID
#define DISP_VTC_ID        XPAR_VTC_0_DEVICE_ID        //VTC  ID
//PL   AXI GPIO 0(lcd_id) ID
#define AXI_GPIO_0_ID      XPAR_AXI_GPIO_0_DEVICE_ID   
//AXI GPIO(lcd_id)  1
#define AXI_GPIO_0_CHANEL  1                           

//The global variable
//frame buffer's   starting address
unsigned int const frame_buffer_addr = (XPAR_PS7_DDR_0_S_AXI_BASEADDR
										+ 0x1000000);
XAxiVdma     vdma;
DisplayCtrl  dispCtrl;
XGpio        axi_gpio_inst;   //PL AXI GPIO  drive

XOv5640_sobel sobel_inst;
VideoMode    vd_mode;
unsigned int lcd_id;

int main(void)
{
	u32 status;
	u16 cmos_h_pixel;   //ov5640 DVP output the number of Horizontal pixel
	u16 cmos_v_pixel;   //ov5640 DVP output the number of Vertical pixel
	u16 total_h_pixel;  //ov5640 the total number of Horizontal pixel
	u16 total_v_pixel;  //ov5640 the total number of Vertical  pixel

	//obtain LCD ID
	XGpio_Initialize(&axi_gpio_inst, AXI_GPIO_0_ID);
	lcd_id = LTDC_PanelID_Read(&axi_gpio_inst,AXI_GPIO_0_CHANEL);
	xil_printf("lcd_id = %x\n\r",lcd_id);

	// according to the ID  of LCD ,select xian shi fen bian lv for OV5640
	switch(lcd_id){
		case 0x4342 :  //4.3 inches,480*272
			cmos_h_pixel = 480;
			cmos_v_pixel = 272;
			total_h_pixel = 1800;
			total_v_pixel = 1000;
			break;
		case 0x4384 :  //4.3 inches,800*480
			cmos_h_pixel = 800;
			cmos_v_pixel = 480;
			total_h_pixel = 1800;
			total_v_pixel = 1000;
			break;
		case 0x7084 :  //7 inches ,800*480
			cmos_h_pixel = 800;
			cmos_v_pixel = 480;
			total_h_pixel = 1800;
			total_v_pixel = 1000;
			break;
		case 0x7016 :  //7 inches,1024*600
			cmos_h_pixel = 1024;
			cmos_v_pixel = 600;
			total_h_pixel = 2200;
			total_v_pixel = 1000;
			break;
		case 0x1018 :  //10.1inches,1280*800
			cmos_h_pixel = 1280;
			cmos_v_pixel = 800;
			total_h_pixel = 2570;
			total_v_pixel = 980;
			break;
		default :
			cmos_h_pixel = 480;
			cmos_v_pixel = 272;
			total_h_pixel = 1800;
			total_v_pixel = 1000;
			break;
	}

	emio_init();                         //Initialize EMIO
	status = ov5640_init( cmos_h_pixel,  //Initialize ov5640
						  cmos_v_pixel,
						 total_h_pixel,
						 total_v_pixel);
	if(status == 0)
		xil_printf("OV5640 detected successful!\r\n");
	else
		xil_printf("OV5640 detected failed!\r\n");

	//according to the ID  of LCD��select Video parameters
	switch(lcd_id){
		case 0x4342 : vd_mode = VMODE_480x272;  break;  //4.3inches,480*272
		case 0x4384 : vd_mode = VMODE_800x480;  break;  //4.3inches,800*480
		case 0x7084 : vd_mode = VMODE_800x480;  break;  //7inches,800*480
		case 0x7016 : vd_mode = VMODE_1024x600; break;  //7inches,1024*600
		case 0x1018 : vd_mode = VMODE_1280x800; break;  //10.1inches,1280*800
		default : vd_mode = VMODE_800x480; break;
	}

	//Initialize Sobel IP
	XOv5640_sobel_Initialize(&sobel_inst,XPAR_OV5640_SOBEL_0_DEVICE_ID);
	//configure Sobel IP hang
	XOv5640_sobel_Set_rows(&sobel_inst, vd_mode.height);
	//configure Sobel IP lie
	XOv5640_sobel_Set_cols(&sobel_inst, vd_mode.width);

	//configure VDMA
	run_vdma_frame_buffer(&vdma, VDMA_ID, vd_mode.width, vd_mode.height,
							frame_buffer_addr,0,0,BOTH);
	//Initialize Display controller
	DisplayInitialize(&dispCtrl, DISP_VTC_ID, DYNCLK_BASEADDR);
    //configure VideoMode
	DisplaySetMode(&dispCtrl, &vd_mode);
	DisplayStart(&dispCtrl);

    return 0;
}

